BINGERL DIDDI QURAN — updated starter website

Files: index.html
Features: Qur'an Arabic text, Hausa translation, and selectable reciters.
Reciters offered: Mishary Rashid Alafasy, Abdurrahman As-Sudais, Mahmoud Khalil Al-Husary, Maher Al-Muaiqly, and Mohamed Siddiq Al-Minshawi.

Requires internet. Text, Hausa translation and audio are loaded from third-party services. Verify audio availability; some reciter editions may not have every audio file at the configured CDN path.

To update GitHub Pages: open your repository, replace the existing index.html with this updated index.html, commit changes, then wait for Pages to redeploy.
